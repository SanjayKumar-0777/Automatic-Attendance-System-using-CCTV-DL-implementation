import tkinter as tk
from PIL import Image, ImageTk
import face_recognition
import numpy as np
import cv2
from datetime import datetime
import mysql.connector
import os
import threading

class FaceRecognitionApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Face Recognition Attendance System")
        self.root.geometry("800x600")

        self.known_face_encodings = []
        self.known_face_names = []
        self.attendance_list = set()
        self.video_capture = None
        self.is_running = False

        self.create_widgets()
        self.load_student_data_from_db()

    def connect_db(self):
        """Function to connect to the database"""
        return mysql.connector.connect(
            host="localhost",
            user="root",
            password="root",
            database="santhosh"
        )

    def create_widgets(self):
        self.start_webcam_button = tk.Button(self.root, text="Start Webcam", command=self.start_webcam)
        self.start_webcam_button.pack(pady=5)

        self.stop_webcam_button = tk.Button(self.root, text="Stop Webcam", command=self.stop_webcam)
        self.stop_webcam_button.pack(pady=5)

        self.status_label = tk.Label(self.root, text="Status: Idle")
        self.status_label.pack(pady=5)

        self.image_frame = tk.Frame(self.root)
        self.image_frame.pack(fill=tk.BOTH, expand=True)

        self.image_panel = tk.Label(self.image_frame)
        self.image_panel.pack(fill=tk.BOTH, expand=True)

    def load_student_data_from_db(self):
        self.known_face_encodings.clear()
        self.known_face_names.clear()

        try:
            connection = self.connect_db()
            cursor = connection.cursor()
            cursor.execute("SELECT name, image_path FROM students")
            students = cursor.fetchall()

            for name, image_path in students:
                if os.path.exists(image_path):
                    image = face_recognition.load_image_file(image_path)
                    encodings = face_recognition.face_encodings(image)

                    if encodings:
                        self.known_face_encodings.append(encodings[0])
                        self.known_face_names.append(name)
                    else:
                        print(f"Warning: No face encoding found in {image_path}")
                else:
                    print(f"Warning: Image {image_path} not found!")

            self.status_label.config(text="Student data loaded successfully.")
        except mysql.connector.Error as error:
            print(f"Database Error: {error}")
        finally:
            cursor.close()
            connection.close()

    def start_webcam(self):
        if not self.is_running:
            self.is_running = True
            self.video_capture = cv2.VideoCapture(0)

            if not self.video_capture.isOpened():
                self.status_label.config(text="Status: Webcam failed to open")
                self.is_running = False
                return

            self.status_label.config(text="Status: Webcam running...")
            threading.Thread(target=self.update_frame, daemon=True).start()

    def stop_webcam(self):
        self.is_running = False
        if self.video_capture:
            self.video_capture.release()
        self.image_panel.config(image='')
        self.status_label.config(text="Status: Webcam stopped")

    def update_frame(self):
        while self.is_running:
            ret, frame = self.video_capture.read()
            if not ret:
                self.status_label.config(text="Status: Camera Frame Error")
                break

            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            face_locations = face_recognition.face_locations(rgb_frame)
            face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)

            for (top, right, bottom, left), face_encoding in zip(face_locations, face_encodings):
                matches = face_recognition.compare_faces(self.known_face_encodings, face_encoding, tolerance=0.6)
                name = "Unknown"

                face_distances = face_recognition.face_distance(self.known_face_encodings, face_encoding)
                if len(face_distances) > 0:
                    best_match_index = np.argmin(face_distances)
                    if matches[best_match_index]:
                        name = self.known_face_names[best_match_index]

                frame_bgr = cv2.cvtColor(rgb_frame, cv2.COLOR_RGB2BGR)

                # Draw rectangle and label
                cv2.rectangle(frame_bgr, (left, top), (right, bottom), (0, 255, 0), 2)
                cv2.rectangle(frame_bgr, (left, bottom - 35), (right, bottom), (0, 255, 0), cv2.FILLED)
                font = cv2.FONT_HERSHEY_SIMPLEX
                cv2.putText(frame_bgr, name, (left + 6, bottom - 6), font, 0.6, (255, 255, 255), 1)

                self.make_attendance_entry(name)

            pil_image = Image.fromarray(cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB))
            imgtk = ImageTk.PhotoImage(image=pil_image)
            self.image_panel.imgtk = imgtk
            self.image_panel.configure(image=imgtk)

        if self.video_capture:
            self.video_capture.release()

    def make_attendance_entry(self, name):
        if name != "Unknown" and name not in self.attendance_list:
            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            self.attendance_list.add(name)

            with open('attendance_list.csv', 'a+') as file:
                file.write(f'{name},{timestamp}\n')

            self.store_attendance_in_db(name, timestamp)

    def store_attendance_in_db(self, name, timestamp):
        try:
            connection = self.connect_db()
            cursor = connection.cursor()
            cursor.execute("INSERT INTO attendance (name, timestamp) VALUES (%s, %s)", (name, timestamp))
            connection.commit()
        except mysql.connector.Error as error:
            print(f"Database Error: {error}")
        finally:
            cursor.close()
            connection.close()

if __name__ == "__main__":
    root = tk.Tk()
    app = FaceRecognitionApp(root)
    root.mainloop()
